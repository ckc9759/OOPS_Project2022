package Parent;

public class ParentUser {
    private String name;

    public ParentUser(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
