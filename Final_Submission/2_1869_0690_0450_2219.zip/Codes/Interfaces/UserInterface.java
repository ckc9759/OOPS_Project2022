package Interfaces;

import Actor.User;

public interface UserInterface {
    void ShowDetails();

    boolean equals(User user);
}
