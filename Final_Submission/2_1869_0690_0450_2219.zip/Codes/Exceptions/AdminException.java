package Exceptions;

public class AdminException extends Exception {
    public AdminException(String s) {
        super(s);
    }
}