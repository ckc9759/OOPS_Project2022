package Exceptions;

public class ValidCityException extends Exception {
    public ValidCityException(String str) {
        super(str);
    }
}
