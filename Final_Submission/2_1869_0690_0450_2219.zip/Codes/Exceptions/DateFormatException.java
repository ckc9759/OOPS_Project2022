package Exceptions;

public class DateFormatException extends Exception {
    public DateFormatException(String str) {
        super(str);
    }

}