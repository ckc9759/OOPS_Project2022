package Exceptions;

public class CreateException extends Exception {

    public CreateException(String message) {
        super(message);
    }
}