package Exceptions;

public class DriverUnavailableException extends Exception {
    public DriverUnavailableException(String message) {
        super(message);
    }
}