package Exceptions;

public class ValidTimeException extends Exception {
    public ValidTimeException(String str) {
        super(str);
    }
}
